/**
 * @Authors
 * 	 Adom Kwabena, Anglaina Hermann
 *
 * @File Name
 *   main.c
 *
 * @Summary
 *   This source file contains the implementation of the project
 *
 * @Description
 *   This code requires TI's driver library from MSP430Ware 3.70.00.05
 */

/**
 * @Section: Included Files
 */

#include <driverlib.h>
#include <stdint.h>
#include "LCD_driver.h"
#include "system.h"
#include "ads8332.h"
#include "dac8411.h"

/**
 * @Section: Main Application
 */

// These variables are declared as globals so they
// can be viewed in the Expressions window during debugging
uint16_t adc_data = 0x0000;
float measured_voltage = 0;

void main(void)
{
	system_initialize();

	while (1)
	{
		// Generate 2.5V at the output of the DAC
		dac8411_send_data(0x9C40);
		// Measure any voltage on the input of the ADC
		adc_data = ads8332_get_conversion(SELECT_CHANNEL_1);
		measured_voltage = 4.096 * (adc_data  / 65535.0);
		delay_ms(500);
	}
}
